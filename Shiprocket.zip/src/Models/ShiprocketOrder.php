<?php

namespace Botble\Shiprocket\Models;

use Illuminate\Database\Eloquent\Model;

class ShiprocketOrder extends Model
{
    protected $table = 'shiprocket_orders';

    protected $fillable = [
        'order_id',                  // Local order id (Botble)
        'shipment_id',               // Shiprocket shipment id
        'shiprocket_order_id',       // Shiprocket order id (if different)
        'status',                    // Last known status from Shiprocket
        'api_response',              // JSON: last response from Shiprocket API
        'synced_at',                 // Timestamp of last sync
        'tracking_data',             // JSON: live tracking data
    ];

    protected $casts = [
        'api_response'   => 'array',
        'tracking_data'  => 'array',
        'synced_at'      => 'datetime',
    ];

    // Relationships

    public function order()
    {
        return $this->belongsTo(\Botble\Ecommerce\Models\Order::class, 'order_id');
    }
    
    public function payments()
{
    return $this->hasOne(Payment::class, 'order_id');
}
}
