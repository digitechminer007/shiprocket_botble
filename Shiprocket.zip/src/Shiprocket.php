<?php

namespace Botble\Shiprocket;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class Shiprocket
{
    protected $token;
    protected $baseUrl = 'https://apiv2.shiprocket.in/v1/external/';
    protected $cacheKey = 'shiprocket_api_token';

    /**
     * Authenticate and store token in cache.
     */
    public function authenticate($email = null, $password = null)
    {
        $email = $email ?: setting('shipping_shiprocket_email');
        $password = $password ?: setting('shipping_shiprocket_password');

        if (Cache::has($this->cacheKey)) {
            $this->token = Cache::get($this->cacheKey);
            return $this->token;
        }

        $response = Http::post($this->baseUrl . 'auth/login', [
            'email' => $email,
            'password' => $password,
        ]);

        if ($response->successful() && isset($response['token'])) {
            $this->token = $response['token'];
            Cache::put($this->cacheKey, $this->token, now()->addHours(10));
            return $this->token;
        } else {
            Log::error('[Shiprocket] Authentication failed: ' . $response->body());
            return null;
        }
    }

    /**
     * Get API token (and auto-authenticate if needed).
     */
    public function getToken()
    {
        if (!$this->token) {
            $this->authenticate();
        }
        return $this->token;
    }

    /**
     * Make a Shiprocket API call.
     */
    protected function api($endpoint, $method = 'get', $data = [])
    {
        $token = $this->getToken();
        $url = $this->baseUrl . ltrim($endpoint, '/');

        $request = Http::withToken($token);

        $response = ($method === 'post')
            ? $request->post($url, $data)
            : $request->get($url, $data);

        if ($response->status() === 401) {
            // Token expired? Try to re-authenticate and re-request
            $this->token = null;
            $token = $this->authenticate();
            $request = Http::withToken($token);
            $response = ($method === 'post')
                ? $request->post($url, $data)
                : $request->get($url, $data);
        }

        // Handle errors
        if (!$response->successful()) {
            Log::error('[Shiprocket] API error: ' . $response->body());
            return [
                'success' => false,
                'message' => $response->json()['message'] ?? 'API error',
                'data'    => $response->json()
            ];
        }

        return $response->json();
    }

    // ---------- Sample API Methods Below ----------

    public function getOrders($params = [])
    {
        return $this->api('orders', 'get', $params);
    }

    public function createOrder($data)
    {
        return $this->api('orders/create/adhoc', 'post', $data);
    }

    public function getOrder($orderId)
    {
        return $this->api("orders/show/$orderId");
    }

    public function cancelOrder($orderId)
    {
        return $this->api('orders/cancel', 'post', ['ids' => [$orderId]]);
    }

    public function trackOrder($shipmentId)
    {
        return $this->api("courier/track", 'get', ['shipment_id' => $shipmentId]);
    }

    public function getPickups()
    {
        return $this->api('pickup-locations'); // <-- Correct endpoint
    }

    public function getWallet()
    {
        return $this->api('wallet/balance'); // <-- Correct endpoint
    }

    // Add more methods as needed...
}

