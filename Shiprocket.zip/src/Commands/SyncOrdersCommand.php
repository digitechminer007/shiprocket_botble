<?php

namespace Botble\Shiprocket\Commands;

use Illuminate\Console\Command;
use Botble\Shiprocket\Services\ShiprocketOrderSyncService;

class SyncOrdersCommand extends Command
{
    protected $signature = 'shiprocket:sync-orders';
    protected $description = 'Sync order statuses from Shiprocket to local DB';

    public function handle(): void
    {
        $service = new ShiprocketOrderSyncService();
        $result = $service->syncStatusesFromShiprocket();

        $this->info("Synced {$result['synced']} order(s), {$result['failed']} failed.");
        
        if (!empty($result['errors'])) {
            foreach ($result['errors'] as $error) {
                $this->error($error);
             }
        }

    }
}
