<?php

namespace Botble\Shiprocket\Commands;

use Illuminate\Console\Command;
use Botble\Shiprocket\Services\ShiprocketOrderSyncService;

class SyncShipmentCommand extends Command
{
    protected $signature = 'shiprocket:sync-shipments';
    protected $description = 'Sync shipment statuses from Shiprocket to local DB';

    public function handle(): void
    {
        $service = new ShiprocketOrderSyncService();
        $result = $service->syncShipmentStatusesFromShiprocket();

        $this->info("Synced {$result['synced']} shipment(s), {$result['failed']} failed.");

        if (!empty($result['errors'])) {
        foreach ($result['errors'] as $error) {
            $this->error($error);
            }
        }
    }
}
