<?php

namespace Botble\Shiprocket\Services;

use Botble\Ecommerce\Models\Order;
use Botble\Ecommerce\Models\Shipment;
use Illuminate\Support\Facades\Log;

class ShiprocketOrderSyncService
{
    protected $api;

    public function __construct()
    {
        $this->api = new ShiprocketApiService();
    }

    /**
     * Push a local order to Shiprocket
     */
    public function syncToShiprocket(Order $order): bool
    {
        try {
            $shipment = Shipment::where('order_id', $order->id)->first();

            // Don't sync if already sent
            if ($shipment && $shipment->shiprocket_shipment_id) {
                Log::info("Order {$order->id} already synced to Shiprocket.");
                return true;
            }


           $result = $this->api->createOrderOnShiprocket($order, $shipment);
            // $shipment will be auto-updated if successful


            Log::channel('shiprocket')->info('Shiprocket Sync Response:', $result);

            // if (isset($result['shipment_id'])) {
            //     // Save shipment ID in your Shipment model
            //     if ($shipment) {
            //         $shipment->shiprocket_shipment_id = $result['shipment_id'];
            //         $shipment->shiprocket_status = 'created';
            //         $shipment->save();
            //     }
            //     return true;
            // }

            Log::error('Shiprocket sync failed: ' . json_encode($result));
        } catch (\Throwable $e) {
            Log::error('Shiprocket sync error: ' . $e->getMessage());
        }
        return false;
    }

    /**
     * Pull order statuses from Shiprocket and update local orders
     */
    public function syncStatusesFromShiprocket(): array
    {
        $synced = $failed = 0;

        $shipments = Shipment::whereNotNull('shiprocket_shipment_id')->get();
        foreach ($shipments as $shipment) {
            try {
                $statusResponse = $this->api->get('courier/track', [
                    'shipment_id' => $shipment->shiprocket_shipment_id,
                ]);
                if (!empty($statusResponse['tracking_data']['current_status'])) {
                    $order = $shipment->order;
                    $order->status = $statusResponse['tracking_data']['current_status'];
                    $order->save();
                    $shipment->shiprocket_status = $statusResponse['tracking_data']['current_status'];
                    $shipment->save();
                    $synced++;
                } else {
                    $failed++;
                }
            } catch (\Throwable $e) {
                Log::error('Shiprocket status pull error: ' . $e->getMessage());
                $failed++;
            }
        }
        return ['synced' => $synced, 'failed' => $failed];
    }

    /**
     * Pull shipment statuses (if different than order logic)
     */
    public function syncShipmentStatusesFromShiprocket(): array
    {
        // You can re-use or modify syncStatusesFromShiprocket() if your shipment logic differs
        return $this->syncStatusesFromShiprocket();
    }
}
