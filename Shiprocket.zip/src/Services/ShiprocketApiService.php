<?php

namespace Botble\Shiprocket\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Exception;

use Botble\Ecommerce\Models\Order;
use Botble\Ecommerce\Models\Shipment;
use Botble\Payment\Models\Payment;

class ShiprocketApiService
{
    protected string $baseUrl = 'https://apiv2.shiprocket.in/v1/external/';
    protected ?string $token = null;
    protected string $cacheKey = 'shiprocket_api_token';

    public function __construct()
    {
        $this->token = $this->getToken();
    }

    public function getToken(): ?string
    {
        $token = Cache::get($this->cacheKey);
        if ($token) {
            return $token;
        }

        $email = setting('shipping_shiprocket_email');
        $password = setting('shipping_shiprocket_password');
        
        \Log::channel('shiprocket')->info($email);
        \Log::channel('shiprocket')->info($password);

        try {
            $response = Http::post($this->baseUrl . 'auth/login', [
                'email' => $email,
                'password' => $password,
            ]);
        } catch (Exception $e) {
            Log::error('Shiprocket token fetch error: ' . $e->getMessage());
            return null;
        }

        if ($response->successful() && isset($response['token'])) {
            Cache::put($this->cacheKey, $response['token'], now()->addHours(9));
            return $response['token'];
        }

        Log::error('Shiprocket: Failed to authenticate, check credentials.');
        return null;
    }

    public function getPickupLocations()
    {
        $token = $this->getToken();
        if (!$token) {
            return ['success' => false, 'message' => 'No API token. Check credentials.'];
        }
    
        $response = Http::withToken($token)
            ->get($this->baseUrl . 'pickup-locations');
    
        if ($response->successful()) {
            return ['success' => true, 'data' => $response->json()['data'] ?? []];
        }
    
        return [
            'success' => false,
            'message' => $response->json()['message'] ?? 'Unable to fetch pickup locations.',
        ];
    }
    // Add a new pickup location
    public function addPickupLocation(array $data)
    {
        $token = $this->getToken();
        if (!$token) {
            return ['success' => false, 'message' => 'No API token. Check credentials.'];
        }
        $response = Http::withToken($token)
            ->post($this->baseUrl . 'pickup-locations/add', $data);
    
        return $response->successful()
            ? ['success' => true, 'data' => $response->json()]
            : ['success' => false, 'message' => $response->json()['message'] ?? 'Failed to add pickup location.'];
    }
    
    // Fetch a single pickup location by ID
    public function getPickupLocation($id)
    {
        $token = $this->getToken();
        if (!$token) {
            return ['success' => false, 'message' => 'No API token. Check credentials.'];
        }
        $response = Http::withToken($token)
            ->get($this->baseUrl . 'pickup-locations/' . $id);
    
        return $response->successful()
            ? ['success' => true, 'data' => $response->json()['data'] ?? []]
            : ['success' => false, 'message' => $response->json()['message'] ?? 'Failed to fetch pickup location.'];
    }
    
    // Update a pickup location
    public function updatePickupLocation($id, array $data)
    {
        $token = $this->getToken();
        if (!$token) {
            return ['success' => false, 'message' => 'No API token. Check credentials.'];
        }
        $response = Http::withToken($token)
            ->post($this->baseUrl . 'pickup-locations/update/' . $id, $data);
    
        return $response->successful()
            ? ['success' => true, 'data' => $response->json()]
            : ['success' => false, 'message' => $response->json()['message'] ?? 'Failed to update pickup location.'];
    }
    
    // Delete a pickup location
    public function deletePickupLocation($id)
    {
        $token = $this->getToken();
        if (!$token) {
            return ['success' => false, 'message' => 'No API token. Check credentials.'];
        }
        $response = Http::withToken($token)
            ->delete($this->baseUrl . 'pickup-locations/' . $id);
    
        return $response->successful()
            ? ['success' => true]
            : ['success' => false, 'message' => $response->json()['message'] ?? 'Failed to delete pickup location.'];
    }


    public function getDashboardStats()
    {
        try {
            $token = $this->getToken();
            if (!$token) {
                throw new Exception('Shiprocket API token is missing!');
            }

            $orderStats = $this->get('orders/stats');
            $wallet     = $this->get('wallet/balance');

            return [
                'success' => true,
                'orders'  => $orderStats['data'] ?? [],
                'wallet'  => $wallet['data'] ?? [],
            ];
        } catch (Exception $e) {
            Log::error('Shiprocket Dashboard API error: ' . $e->getMessage());
            return [
                'success' => false,
                'orders' => [],
                'wallet' => [],
                'error'  => $e->getMessage(),
            ];
        }
    }

    public function getWallet()
    {
        $token = $this->getToken();
        if (!$token) {
            return ['success' => false, 'message' => 'Unable to authenticate with Shiprocket.'];
        }

        $response = $this->get('wallet/balance');
        return [
            'success' => true,
            'data'    => $response['data'] ?? [],
        ];
    }

    public function get($endpoint, $params = [])
    {
        if (!$this->token) {
            return ['success' => false, 'message' => 'Shiprocket API token missing'];
        }

        $response = Http::withToken($this->token)
            ->get($this->baseUrl . $endpoint, $params);

        return $response->json();
    }

    public function post($endpoint, $data = [])
    {
        if (!$this->token) {
            return ['success' => false, 'message' => 'Shiprocket API token missing'];
        }

        $response = Http::withToken($this->token)
            ->post($this->baseUrl . $endpoint, $data);

        return $response->json();
    }

    public function syncAllReadyOrders()
    {
        $orders = Order::where('status', 'ready_to_be_shipped_out')->get();
        $synced = 0;
        $failed = 0;

        foreach ($orders as $order) {
            try {
                $shipment = Shipment::where('order_id', $order->id)->first();
                if ($shipment && !$shipment->shiprocket_shipment_id) {
                    $result = $this->createOrderOnShiprocket($order, $shipment);
                    if ($result['success'] ?? false) {
                        $synced++;
                    } else {
                        $failed++;
                    }
                }
            } catch (\Exception $e) {
                Log::error("Shiprocket sync failed for order {$order->id}: " . $e->getMessage());
                $failed++;
            }
        }
        return [
            'synced' => $synced,
            'failed' => $failed,
        ];
    }

    public function testConnection(): array
    {
        $email = setting('shipping_shiprocket_email');
        $password = setting('shipping_shiprocket_password');

        try {
            $response = Http::post($this->baseUrl . 'auth/login', [
                'email' => $email,
                'password' => $password,
            ]);
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Connection failed! ' . $e->getMessage(),
            ];
        }

        if ($response->successful() && isset($response['token'])) {
            return [
                'success' => true,
                'token' => $response['token'],
                'message' => 'Connection successful!',
            ];
        } else {
            return [
                'success' => false,
                'message' => 'Connection failed! ' . ($response['message'] ?? 'Check credentials.'),
                'data' => $response->json(),
            ];
        }
    }

    public function getShippingRates(array $data)
    {
        $token = $this->getToken();
        if (!$token) {
            return ['success' => false, 'error' => 'API token not available.'];
        }

        // Validate keys
        $params = [
            'pickup_postcode'   => $data['pickup_postcode'] ?? '',
            'delivery_postcode' => $data['delivery_postcode'] ?? '',
            'weight'            => $data['weight'] ?? 0.5,
            'cod'               => $data['cod'] ?? 0,
        ];

        $response = Http::withToken($token)
            ->get($this->baseUrl . 'courier/serviceability/', $params);

        return $response->json();
    }

   public function createOrderOnShiprocket(Order $order, Shipment $shipment = null)
    {
        $customer = $order->address; // Eloquent relation, not $order->user!
        
        $payment = \Botble\Payment\Models\Payment::find($order->payment_id);

        $paymentChannel = $payment ? $payment->payment_channel : null;


        $phone = preg_replace('/\D/', '', $customer->phone ?? '9999999999');
        $phone = substr($phone, -10);
        if (strlen($phone) !== 10) $phone = '9999999999';
        
        $payload = [
            'order_id'              => $order->code,
            'order_date'            => now()->toDateString(),
            'shipping_is_billing'   => 1, // Always set, 1 means true
            'pickup_location'       => 'Workshop',
            'billing_customer_name' => $customer->name ?? 'Guest',
            'billing_last_name'     => $customer->last_name ?? '', // If not present, send empty string
            'billing_address'       => $customer->address ?? 'Unknown',
            'billing_city'          => $customer->city ?? 'City',
            'billing_state'         => $customer->state ?? 'State',
            'billing_country'       => $customer->country ?? 'India',
            'billing_pincode'       => $customer->zip_code ?? '000000',
            'billing_email'         => $customer->email ?? 'email@example.com',
            'billing_phone'         => $phone,
            
            'order_items'           => $order->products->map(function ($product) {
                return [
                    'name' => $product->product_name,
                    'sku'  => $product->product->sku ?? '',
                    'units' => $product->qty,
                    'selling_price' => $product->price,
                    'length' => $product->length ?? 10,
                    'breadth' => $product->wide ?? 10,
                    'height' => $product->height ?? 10,
                    'weight' => $product->weight ?? 1,
                ];
            })->toArray(),
            'payment_method' => ($paymentChannel && strtolower($paymentChannel) === 'cod') ? 'COD' : 'Prepaid',
            'sub_total'      => $order->sub_total,
            // Overall shipment dimensions (required, even if repeated per item)
            'length'         => 10,
            'breadth'        => 10,
            'height'         => 10,
            'weight'         => 1,
            
        ];
    
        \Log::channel('shiprocket')->info('Sync payload', $payload);
    
        $token = $this->getToken();
        $response = Http::withToken($token)
            ->post($this->baseUrl . 'orders/create/adhoc', $payload)
            ->json();
    
        \Log::channel('shiprocket')->info('Sync response', $response);
        \Log::channel('shiprocket')->info('Sanitized phone', ['order' => $order->id, 'phone' => $phone]);

        if (($response['status'] ?? 0) == 1) {
            // Update shipment with new Shiprocket ID/status
            if ($shipment) {
                $shipment->shiprocket_shipment_id = $response['shipment_id'] ?? null;
                $shipment->shiprocket_status = 'created';
                $shipment->save();
            }
            return ['success' => true, 'message' => 'Order synced!', 'response' => $response];
        } else {
            return ['success' => false, 'message' => $response['message'] ?? 'Unknown error', 'response' => $response];
        }
    }

}
