<?php

if (!function_exists('shiprocket_mask_string')) {
    /**
     * Mask a string except the last few characters (for showing part of API keys, etc)
     */
    function shiprocket_mask_string($string, $visible = 4)
    {
        $length = strlen($string);
        if ($length <= $visible) {
            return str_repeat('*', $length);
        }
        return str_repeat('*', $length - $visible) . substr($string, -$visible);
    }
}

if (!function_exists('shiprocket_order_status_badge')) {
    /**
     * Return a HTML badge for order status
     */
    function shiprocket_order_status_badge($status)
    {
        $map = [
            'pending' => 'badge-warning',
            'in_transit' => 'badge-info',
            'delivered' => 'badge-success',
            'cancelled' => 'badge-danger',
            'returned' => 'badge-secondary',
            'picked_up' => 'badge-primary',
        ];
        $label = ucfirst(str_replace('_', ' ', $status));
        $class = $map[$status] ?? 'badge-light';

        return '<span class="badge ' . $class . '">' . $label . '</span>';
    }
}

if (!function_exists('shiprocket_admin_can')) {
    /**
     * Check if current user can access Shiprocket menu (permission stub)
     */
    function shiprocket_admin_can($ability)
    {
        // You can hook to Botble�s permission system here, e.g.:
        // return auth()->user()->hasPermission('shiprocket.' . $ability);
        return true;
    }
}
