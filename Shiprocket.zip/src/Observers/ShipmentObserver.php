<?php

namespace Botble\Shiprocket\Observers;

use Botble\Ecommerce\Models\Shipment;
use Botble\Ecommerce\Models\Order;
use Illuminate\Support\Facades\Log;
use Botble\Shiprocket\Services\ShiprocketApiService;
use Botble\Shiprocket\Services\ShiprocketOrderService;


class ShipmentObserver
{
    /**
     * Handle the Shipment "updated" event.
     */
    public function updated(Shipment $shipment)
    {
        // Log the update event for debugging
        Log::channel('shiprocket')->info('Shipment updated observer fired', [
            'shipment_id' => $shipment->id,
            'new_status' => $shipment->status,
            'old_status' => $shipment->getOriginal('status'),
        ]);
        
        $status = (string) $shipment->status;
    
        $oldStatus = (string) $shipment->getOriginal('status');

 Log::channel('shiprocket')->info('Shipment updated status found => ',[$status]);

        if ( $status === 'ready_to_be_shipped_out') {
            Log::channel('shiprocket')->info('Status is now ready_to_be_shipped_out, checking for sync...');
    
            //Log::channel('shiprocket')->info('shiprocket shipment id',[$shipment->shiprocket_shipment_id]);
            
            if (!$shipment->shiprocket_shipment_id) {
            
                $order = $shipment->order;
                Log::channel('shiprocket')->info('Syncing to Shiprocket now...', [
                    'order_id' => $order->id ?? null,
                ]);
                app(ShiprocketApiService::class)->createOrderOnShiprocket($order, $shipment);
            } else {
                Log::channel('shiprocket')->info('Already synced to Shiprocket, skipping...');
            }
        }
        
        
        
        
        
        
        
    }
}
