<?php

namespace Botble\Shiprocket\Observers;

use Botble\Ecommerce\Models\Order;
use Botble\Ecommerce\Models\Shipment;
use Botble\Shiprocket\Services\ShiprocketOrderService;
use Illuminate\Support\Facades\Log;

use Botble\Shiprocket\Services\ShiprocketApiService;



class OrderObserver
{
    /**
     * Handle the Order "created" event.
     */
    public function created(Order $order)
    {
        // Auto sync order to Shiprocket when it's first created (optional).
        // $this->syncToShiprocketIfNeeded($order, 'created');
    }

    /**
     * Handle the Order "updated" event.
     */
    public function updated(Order $order)
    {
        // Auto sync when order status is "ready to be shipped out".
        // if ($order->status === 'ready_to_be_shipped_out') {
        //     $this->syncToShiprocketIfNeeded($order, 'updated');
        // }
        
        // if ($order->isDirty('status') && $order->shipment->status === 'ready_to_be_shipped_out') {
        //     $shipment = $order->shipment;
        //     if ($shipment && !$shipment->shiprocket_shipment_id) {
        //         // Only sync if not already synced
        //         app(ShiprocketApiService::class)->createOrderOnShiprocket($order, $shipment);
        //     }
        // }
    }
 
    /**
     * Push order to Shiprocket if not already done.
     */
    protected function syncToShiprocketIfNeeded(Order $order, string $eventType)
    {
        // try {
        //     $shipment = Shipment::where('order_id', $order->id)->first();

            // Only sync if not already synced.
        //     if ($shipment && empty($shipment->shiprocket_shipment_id)) {
        //         app(ShiprocketOrderService::class)->syncSingle($order);
        //         Log::info("[Shiprocket] Order #{$order->code} synced on $eventType.");
        //     }
        // } catch (\Exception $e) {
        //     Log::error("[Shiprocket] Error syncing order #{$order->code}: " . $e->getMessage());
        // }
    }

    // Optionally: Add deleted/restored/forceDeleted if needed.
}
