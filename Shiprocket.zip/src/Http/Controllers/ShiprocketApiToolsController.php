<?php

namespace Botble\Shiprocket\Http\Controllers;

use Botble\Base\Http\Controllers\BaseController;
use Botble\Shiprocket\Services\ShiprocketApiService;
use Illuminate\Http\Request;

class ShiprocketApiToolsController extends BaseController
{
    protected $shiprocketApi;

    public function __construct(ShiprocketApiService $shiprocketApi)
    {
        $this->shiprocketApi = $shiprocketApi;
    }
    public function index()
    {
        // You may want to fetch some data/tools here later.
        return view('plugins.shiprocket::apitools');
    }

    public function testConnection()
    {
        $result = $this->shiprocketApi->testConnection();
    //return response()->json(['result' => $result]);
    
        return redirect()->route('shiprocket.settings')
        ->with('api_status', [
            'success' => $result['success'] ?? false,
            'message' => $result['message'] ?? 'No response',
        ]);
        
    }

    public function fetchCarriers()
    {
        $carriers = $this->shiprocketApi->getCarriers();
        return response()->json(['carriers' => $carriers]);
    }

    public function manualOrderSync(Request $request)
    {
        $orderId = $request->input('order_id');
        $result = $this->shiprocketApi->syncOrderById($orderId);
        return response()->json(['result' => $result]);
    }

 public function getRates(Request $request)
    {
  
    
    $rates = $this->shiprocketApi->getShippingRates([
            'pickup_postcode'   => $request->input('from_pincode'),
            'delivery_postcode' => $request->input('to_pincode'),
            'weight'            => $request->input('weight'),
            'cod'               => 0, // Or get from request
        ]);

    $couriers = $rates['data']['available_courier_companies'] ?? [];
    return view('plugins.shiprocket::settings', compact('couriers'));

     //return response()->json(['rates' => $rates]);
     
    }
    // Add more API actions as needed.
}
