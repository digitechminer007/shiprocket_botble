<?php

namespace Botble\Shiprocket\Http\Controllers;

use Botble\Base\Http\Controllers\BaseController;
use Botble\Ecommerce\Models\Order;
use Botble\Shiprocket\Services\ShiprocketApiService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Botble\Ecommerce\Models\Shipment;
use Illuminate\Http\RedirectResponse;


class ShiprocketOrderController extends BaseController
{
    protected $shiprocketApi;

    public function __construct(ShiprocketApiService $shiprocketApi)
    {
        $this->shiprocketApi = $shiprocketApi;
    }

    public function index(Request $request)
    {
        page_title()->setTitle('Shiprocket Orders');

        // Optionally filter by status, etc.
        $orders = Order::whereHas('shipment', function ($q) {
            $q->whereNull('shiprocket_shipment_id');
        })->paginate(20);
        
        return view('plugins.shiprocket::orders', compact('orders'));
    }

    public function sync(Request $request)
    {
        // Sync all "ready to ship" orders to Shiprocket
        $result = $this->shiprocketApi->syncAllReadyOrders();
        return redirect()->back()->with('status', $result ? 'Orders synced!' : 'No new orders to sync.');
    }


    public function syncSingle($orderId, Request $request): RedirectResponse
    {
        $order = Order::findOrFail($orderId);
        $shipment = Shipment::where('order_id', $order->id)->first();

        // Try to sync this order to Shiprocket
        $result = $this->shiprocketApi->createOrderOnShiprocket($order, $shipment);

        if ($result['success'] ?? false) {
            return back()->with('status', 'Order synced to Shiprocket!');
        } else {
            return back()->with('error', $result['message'] ?? 'Failed to sync order.');
        }
        
         return redirect()->back()->with('success', 'Order synced!');
    }
    

    
    public function details($orderId)
    {
        $order = Order::with('shipment')->findOrFail($orderId);
        $shipment = $order->shipment;

        // Fetch real-time Shiprocket status
        $shipmentStatus = null;
        if ($shipment && $shipment->shiprocket_shipment_id) {
            $shipmentStatus = $this->shiprocketApi->getShipmentStatus($shipment->shiprocket_shipment_id);
        }

        return view('plugins.shiprocket::order-detail', compact('order', 'shipment', 'shipmentStatus'));
    }
}
