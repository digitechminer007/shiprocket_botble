<?php

namespace Botble\Shiprocket\Http\Controllers;

use Botble\Base\Http\Controllers\BaseController;

class ShiprocketPublicController extends BaseController
{
    public function trackPage()
    {
        
         if (!setting('shiprocket_public_tracking_enabled', true)) {
            abort(404);
            }
    
        page_title()->setTitle('Track Your Order');
        return view('plugins/shiprocket::frontend.track');
        
    }
}
