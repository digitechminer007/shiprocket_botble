<?php

namespace Botble\Shiprocket\Http\Controllers;

use Botble\Base\Http\Controllers\BaseController;
use Botble\Shiprocket\Services\ShiprocketApiService;
use Illuminate\Http\Request;
class ShiprocketWalletController extends BaseController
{
    protected $shiprocketApi;

    public function __construct(ShiprocketApiService $shiprocketApi)
    {
        $this->shiprocketApi = $shiprocketApi;
    }

    public function index()
    {
        page_title()->setTitle('Shiprocket Wallet');
        $wallet = $this->shiprocketApi->getWallet();

        return view('plugins.shiprocket::wallet', compact('wallet'));
    }
    
    public function recharge(Request $request)
    {
        $request->validate([
            'amount' => 'required|numeric|min:1',
        ]);
        // Here, integrate with Shiprocket wallet recharge API if available
        // For now, flash a message
        return redirect()->back()->with('status', 'Recharge request sent! (Integrate with Shiprocket API)');
    }
    
     public function update(ShiprocketSettingRequest $request)
    {
 $request->validate([
            'amount' => 'required|numeric|min:1',
        ]);
        // Here, integrate with Shiprocket wallet recharge API if available
        // For now, flash a message
        return redirect()->back()->with('status', 'Recharge request sent! (Integrate with Shiprocket API)');
    }

}
