<?php

namespace Botble\Shiprocket\Http\Controllers;

use Botble\Base\Http\Controllers\BaseController;
use Botble\Shiprocket\Services\ShiprocketApiService;
use Illuminate\Http\Request;

class ShiprocketPickupController extends BaseController
{
    protected $shiprocketApi;

    public function __construct(ShiprocketApiService $shiprocketApi)
    {
        $this->shiprocketApi = $shiprocketApi;
    }

    public function index()
    {
        page_title()->setTitle('Pickup Locations');

        $pickups = [];
        $error = null;
    
        $response = $this->shiprocketApi->getPickupLocations();
        
        \Log::channel('shiprocket')->info('Pickup Locations', [$response]);
    
        if (!is_array($response)) $response = [];
        if (!($response['success'] ?? false)) {
            $error = $response['message'] ?? 'Unable to fetch pickup locations from Shiprocket API.';
        } else {
            $pickups = $response['data'] ?? [];
        }
    
        // Pass pickups to the view (you can also pass $error if needed)
        return view('plugins.shiprocket::pickups', compact('pickups', 'error'));
    }

    public function create()
    {
        page_title()->setTitle('Add Pickup Location');
        return view('plugins.shiprocket::pickup-create');
    }

    public function store(Request $request)
    {
        $result = $this->shiprocketApi->addPickupLocation($request->all());
        return redirect()->route('shiprocket.pickups.index')
            ->with('status', $result['success'] ? 'Location added!' : ($result['message'] ?? 'Failed to add location.'));
    }

    public function edit($id)
    {
        page_title()->setTitle('Edit Pickup Location');
        $pickup = $this->shiprocketApi->getPickupLocation($id);

        if (!($pickup['success'] ?? false)) {
            return redirect()->route('shiprocket.pickups.index')->with('error', $pickup['message'] ?? 'Pickup location not found.');
        }

        return view('plugins.shiprocket::pickup-edit', ['pickup' => $pickup['data']]);
    }

    public function update(Request $request, $id)
    {
        $result = $this->shiprocketApi->updatePickupLocation($id, $request->all());
        return redirect()->route('shiprocket.pickups.index')
            ->with('status', $result['success'] ? 'Location updated!' : ($result['message'] ?? 'Failed to update location.'));
    }

    public function destroy($id)
    {
        $result = $this->shiprocketApi->deletePickupLocation($id);
        return redirect()->route('shiprocket.pickups.index')
            ->with('status', $result['success'] ? 'Deleted!' : ($result['message'] ?? 'Failed to delete location.'));
    }
}
