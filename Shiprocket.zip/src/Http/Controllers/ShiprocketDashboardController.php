<?php

namespace Botble\Shiprocket\Http\Controllers;

use Botble\Base\Http\Controllers\BaseController;
use Botble\Shiprocket\Services\ShiprocketApiService;
use Botble\Ecommerce\Models\Shipment; // Add this use statement

class ShiprocketDashboardController extends BaseController
{
    protected $shiprocketApi;

    public function __construct(ShiprocketApiService $shiprocketApi)
    {
        $this->shiprocketApi = $shiprocketApi;
    }

    public function index()
    {
        page_title()->setTitle('Shiprocket Dashboard');
        $stats = $this->shiprocketApi->getDashboardStats();

        // Fetch the 5 most recent shipments (or whatever number you prefer)
        $recentShipments = Shipment::orderByDesc('created_at')->limit(20)->get();

        return view('plugins.shiprocket::dashboard', compact('stats', 'recentShipments'));
    }
}
