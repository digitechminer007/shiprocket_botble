<?php

namespace Botble\Shiprocket\Http\Controllers;

use Botble\Base\Http\Controllers\BaseController;
use Botble\Base\Http\Responses\BaseHttpResponse;
use Botble\Shiprocket\Http\Requests\ShiprocketSettingRequest;
use Botble\Setting\Supports\SettingStore;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;


class ShiprocketSettingController extends BaseController
{
    public function index()
    {
        page_title()->setTitle('Shiprocket Settings');
        return view('plugins.shiprocket::settings');
    }

    public function update(
    ShiprocketSettingRequest $request,
    BaseHttpResponse $response,
    SettingStore $settingStore
) {
    // Save shipping_shiprocket_* settings
    $data = Arr::where($request->except(['_token']), function ($value, $key) {
        return Str::startsWith($key, 'shipping_shiprocket_');
    });

    foreach ($data as $settingKey => $settingValue) {
        $settingStore->set($settingKey, is_string($settingValue) ? trim($settingValue) : $settingValue);
    }

    // ✅ Save public tracking setting explicitly
    $settingStore->set(
        'shiprocket_public_tracking_enabled',
        $request->boolean('shiprocket_public_tracking_enabled')
    );

    $settingStore->save();

    return $response->setMessage('Shiprocket settings saved successfully!');
}

    
    
}
