<?php

namespace Botble\Shiprocket\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class WebhookMiddleware
{
    /**
     * Handle an incoming webhook request.
     *
     * Optionally, validate signature if Shiprocket provides one.
     */
    public function handle(Request $request, Closure $next)
    {
        // Example: Check for a webhook secret header
        $providedSecret = $request->header('X-Shiprocket-Webhook-Secret');
        $validSecret = config('shiprocket.webhook_secret');

        if ($validSecret && $providedSecret !== $validSecret) {
            abort(403, 'Invalid webhook signature.');
        }

        return $next($request);
    }
}
