<?php

namespace Botble\Shiprocket\Http\Requests;

use Botble\Support\Http\Requests\Request;

class ShiprocketSettingRequest extends Request
{
    public function rules(): array
    {
        return [
            'shipping_shiprocket_email'    => 'required|email',
            'shipping_shiprocket_password' => 'required|string|min:6',
            // Add other required settings validation here
        ];
    }

    public function messages(): array
    {
        return [
            'shipping_shiprocket_email.required'    => 'Shiprocket Email is required.',
            'shipping_shiprocket_email.email'       => 'A valid email is required.',
            'shipping_shiprocket_password.required' => 'Shiprocket Password is required.',
        ];
    }
}
