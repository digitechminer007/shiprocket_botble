<?php

namespace Botble\Shiprocket\Providers;

use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
// use Botble\Ecommerce\Models\Order;
// use Botble\Shiprocket\Observers\OrderObserver;

use Botble\Ecommerce\Models\Shipment;
use Botble\Shiprocket\Observers\ShipmentObserver;

class EventServiceProvider extends ServiceProvider
{
    protected $listen = [];

    public function boot(): void
    {
        parent::boot();

        // Register order observer for auto-sync
       // Order::observe(OrderObserver::class);
        Shipment::observe(ShipmentObserver::class);
    }
}
