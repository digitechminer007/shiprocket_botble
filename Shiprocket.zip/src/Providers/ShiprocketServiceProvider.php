<?php

namespace Botble\Shiprocket\Providers;

use Botble\Base\Traits\LoadAndPublishDataTrait;
use Illuminate\Support\ServiceProvider;
use Illuminate\Routing\Events\RouteMatched;
use Botble\Base\Facades\DashboardMenu;
use Illuminate\Support\Facades\Event;
use Botble\Shiprocket\Observers\OrderObserver;
use Botble\Ecommerce\Models\Order;
use Botble\Ecommerce\Models\Shipment;
use Botble\Shiprocket\Observers\ShipmentObserver;

class ShiprocketServiceProvider extends ServiceProvider
{
    use LoadAndPublishDataTrait;

    public function register(): void
    {
        $this->setNamespace('plugins/shiprocket')
            ->loadHelpers();

        $this->app->register(CommandServiceProvider::class);
        $this->app->register(EventServiceProvider::class);
        if (class_exists(HookServiceProvider::class)) {
            $this->app->register(HookServiceProvider::class);
        }

        $this->app->singleton('shiprocket', function ($app) {
            return new \Botble\Shiprocket\Shiprocket();
        });
    }

    public function boot(): void
    {
        $this
            ->loadAndPublishTranslations()
            ->loadAndPublishViews()
            ->loadRoutes(['web'])
            ->loadAndPublishConfigurations(['shiprocket'])
            ->publishAssets()
            ->loadViewsFrom(__DIR__ . '/../../resources/views', 'plugins.shiprocket');

        Event::listen(RouteMatched::class, function () {
            // Main Shiprocket menu (Sidebar)
            DashboardMenu::registerItem([
                'id'          => 'cms-shiprocket',
                'priority'    => 30,
                'parent_id'   => null,
                'name'        => 'Shiprocket',
                'icon'        => 'fa fa-rocket',
                'url'         => route('shiprocket.dashboard'),
                'permissions' => ['shiprocket.index'],
            ]);
            // Submenu: Dashboard/Overview
            DashboardMenu::registerItem([
                'id'          => 'cms-shiprocket-dashboard',
                'priority'    => 0,
                'parent_id'   => 'cms-shiprocket',
                'name'        => 'Overview',
                'icon'        => 'fa fa-tachometer-alt',
                'url'         => route('shiprocket.dashboard'),
                'permissions' => ['shiprocket.index'],
            ]);
            // Submenu: Orders
            DashboardMenu::registerItem([
                'id'          => 'cms-shiprocket-orders',
                'priority'    => 1,
                'parent_id'   => 'cms-shiprocket',
                'name'        => 'Orders',
                'icon'        => 'fa fa-shopping-bag',
                'url'         => route('shiprocket.orders'),
                'permissions' => ['shiprocket.orders'],
            ]);
            // Submenu: Wallet
            DashboardMenu::registerItem([
                'id'          => 'cms-shiprocket-wallet',
                'priority'    => 2,
                'parent_id'   => 'cms-shiprocket',
                'name'        => 'Wallet',
                'icon'        => 'fa fa-wallet',
                'url'         => route('shiprocket.wallet'),
                'permissions' => ['shiprocket.wallet'],
            ]);
            // Submenu: API Tools
            // DashboardMenu::registerItem([
            //     'id'          => 'cms-shiprocket-apitools',
            //     'priority'    => 3,
            //     'parent_id'   => 'cms-shiprocket',
            //     'name'        => 'API Tools',
            //     'icon'        => 'fa fa-toolbox',
            //     'url'         => route('shiprocket.apitools'),
            //     'permissions' => ['shiprocket.apitools'],
            // ]);
            
            // Submenu: Pickup Locations
            DashboardMenu::registerItem([
                'id'          => 'cms-shiprocket-pickups',
                'priority'    => 4,
                'parent_id'   => 'cms-shiprocket',
                'name'        => 'Pickup Locations',
                'icon'        => 'fa fa-map-marker-alt',
                'url'         => route('shiprocket.pickups.index'),
                'permissions' => ['shiprocket.pickups'],
            ]);
            // Submenu: Settings
            DashboardMenu::registerItem([
                'id'          => 'cms-shiprocket-settings',
                'priority'    => 5,
                'parent_id'   => 'cms-shiprocket',
                'name'        => 'Settings',
                'icon'        => 'fa fa-cog',
                'url'         => route('shiprocket.settings'),
                'permissions' => ['shiprocket.settings'],
            ]);
            // Submenu: Logs
            DashboardMenu::registerItem([
                'id'          => 'cms-shiprocket-logs',
                'priority'    => 6,
                'parent_id'   => 'cms-shiprocket',
                'name'        => 'Logs',
                'icon'        => 'fa fa-file-alt',
                'url'         => route('shiprocket.logs'),
                'permissions' => ['shiprocket.logs'],
            ]);
        });

        // Register observer to handle syncing orders with Shiprocket
        //Order::observe(OrderObserver::class);
       // Shipment::observe(ShipmentObserver::class);
    }
}
