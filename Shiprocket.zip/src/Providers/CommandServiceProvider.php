<?php

namespace Botble\Shiprocket\Providers;

use Illuminate\Support\ServiceProvider;

class CommandServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        if ($this->app->runningInConsole()) {
            $this->commands([
                \Botble\Shiprocket\Commands\SyncOrdersCommand::class,
            ]);
        }
    }
}
