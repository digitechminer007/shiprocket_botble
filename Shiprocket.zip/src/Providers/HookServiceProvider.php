<?php

namespace Botble\Shiprocket\Providers;

use Illuminate\Support\ServiceProvider;

class HookServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        // Add hooks if needed
    }
}
