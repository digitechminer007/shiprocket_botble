<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddShiprocketFieldsToShipmentsTable extends Migration
{
    public function up()
    {
        Schema::table('ec_shipments', function (Blueprint $table) {
            $table->string('shiprocket_shipment_id')->nullable()->after('id');
            $table->text('shiprocket_raw_response')->nullable()->after('shiprocket_shipment_id');
        });
    }

    public function down()
    {
        Schema::table('ec_shipments', function (Blueprint $table) {
            $table->dropColumn(['shiprocket_shipment_id', 'shiprocket_raw_response']);
        });
    }
}
