<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateShiprocketOrdersTable extends Migration
{
    public function up()
    {
        Schema::create('shiprocket_orders', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('order_id')->index();
            $table->string('shipment_id')->nullable();
            $table->string('shiprocket_order_id')->nullable();
            $table->string('status')->nullable();
            $table->json('api_response')->nullable();
            $table->timestamp('synced_at')->nullable();
            $table->json('tracking_data')->nullable();
            $table->timestamps();

            $table->foreign('order_id')
                ->references('id')->on('ec_orders')
                ->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::dropIfExists('shiprocket_orders');
    }
}
