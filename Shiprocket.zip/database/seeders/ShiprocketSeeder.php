<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Botble\Shiprocket\Models\ShiprocketOrder;
use Botble\Ecommerce\Models\Order;

class ShiprocketSeeder extends Seeder
{
    public function run()
    {
        // Get first 5 local orders (for demo)
        $orders = Order::take(5)->get();

        foreach ($orders as $order) {
            ShiprocketOrder::create([
                'order_id'         => $order->id,
                'shipment_id'      => 'SRKDEMO-' . rand(100000, 999999),
                'shiprocket_order_id' => 'SRKORDER-' . rand(100000, 999999),
                'status'           => 'pending',
                'api_response'     => [
                    'demo' => true,
                    'note' => 'Seeded for testing',
                ],
                'synced_at'        => now(),
                'tracking_data'    => [
                    'tracking_url' => 'https://track.shiprocket.in/seed/' . rand(100000, 999999),
                    'status' => 'pending',
                ],
            ]);
        }
    }
}
