<?php

return [
    'shiprocket' => 'Shiprocket',
    'settings' => 'Settings',
    'orders' => 'Orders',
    'dashboard' => 'Dashboard',
    'wallet' => 'Wallet',
    'pickups' => 'Pickup Locations',
    'api_tools' => 'API Tools',
    'logs' => 'Logs',
    'sync_now' => 'Sync Now',
    'create_shipment' => 'Create Shipment',
    'status' => 'Status',
    'actions' => 'Actions',
    'save' => 'Save',
    'saved_shipping_settings_success' => 'Shiprocket settings updated successfully.',
    'api_credentials_invalid' => 'Invalid Shiprocket API credentials.',
    'no_shipments_found' => 'No Shiprocket shipments found to sync.',
    'order_synced' => 'Order synced with Shiprocket.',
    'error' => 'An error occurred. Please check your credentials and try again.',
    'admin_only' => 'You must be an administrator to access this section.',
    // Add more as needed
];
