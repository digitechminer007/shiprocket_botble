﻿{{-- resources/views/dashboard.blade.php --}}
@extends('plugins/shiprocket::layouts.master')

@section('shiprocket-content')
    <h3 class="mb-4">{{ __('Shiprocket Dashboard') }}</h3>
    <div class="row">
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5>{{ __('Synced Orders') }}</h5>
                    <h3>{{ $stats['synced'] ?? 0 }}</h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5>{{ __('Pending Sync') }}</h5>
                    <h3>{{ $stats['pending'] ?? 0 }}</h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5>{{ __('Delivered') }}</h5>
                    <h3>{{ $stats['delivered'] ?? 0 }}</h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5>{{ __('Wallet Balance') }}</h5>
                    <h3>₹ {{ $wallet['balance'] ?? 0 }}</h3>
                </div>
            </div>
        </div>
    </div>
    <h4 class="mt-5">{{ __('Recent Shipments') }}</h4>
    <ul class="list-group">
        @forelse ($recentShipments as $shipment)
            <li class="list-group-item">
                <strong>{{ $shipment->order->code }}</strong> —
                {{ $shipment->shiprocket_status ?? __('Not Synced') }} 
                <span class="float-end">{{ $shipment->created_at->format('d M Y H:i') }}</span>
            </li>
        @empty
            <li class="list-group-item">{{ __('No recent shipments.') }}</li>
        @endforelse
    </ul>
@endsection
