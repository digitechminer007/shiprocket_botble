{{-- resources/views/wallet.blade.php --}}
@extends('plugins.shiprocket::layouts.master')

@section('shiprocket-content')
    <h4 class="mb-3">{{ __('Shiprocket Wallet') }}</h4>
    <div class="d-flex align-items-center mb-4">
        <span class="fw-bold me-2">{{ __('Balance:') }}</span>
        <span class="badge fs-5 me-4">₹ {{ $wallet['balance'] ?? 0 }}</span>
        <!-- Recharge Button -->
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#walletRechargeModal">
            <i class="fa fa-plus-circle"></i> {{ __('Recharge Wallet') }}
        </button>
    </div>

    <h5 class="mb-3">{{ __('Wallet History') }}</h5>
    <table class="table table-bordered table-hover">
        <thead>
            <tr>
                <th>{{ __('Date') }}</th>
                <th>{{ __('Type') }}</th>
                <th>{{ __('Amount') }}</th>
                <th>{{ __('Remarks') }}</th>
            </tr>
        </thead>
        <tbody>
            @forelse($wallet['history'] ?? [] as $item)
                <tr>
                    <td>{{ \Carbon\Carbon::parse($item['date'])->format('d M Y') }}</td>
                    <td>
                        @if($item['type'] === 'credit')
                            <span class="badge bg-success">{{ __('Credit') }}</span>
                        @else
                            <span class="badge bg-danger">{{ __('Debit') }}</span>
                        @endif
                    </td>
                    <td>₹ {{ $item['amount'] }}</td>
                    <td>{{ $item['remarks'] }}</td>
                </tr>
            @empty
                <tr>
                    <td colspan="4">{{ __('No wallet transactions found.') }}</td>
                </tr>
            @endforelse
        </tbody>
    </table>

    <!-- Recharge Modal -->
    <div class="modal fade" id="walletRechargeModal" tabindex="-1" aria-labelledby="walletRechargeModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <form method="POST" action="{{ route('shiprocket.wallet.recharge') }}">
            @csrf
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="walletRechargeModalLabel">{{ __('Recharge Wallet') }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <div class="mb-3">
                    <label for="amount" class="form-label">{{ __('Amount') }}</label>
                    <input type="number" min="1" class="form-control" name="amount" id="amount" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ __('Cancel') }}</button>
                <button type="submit" class="btn btn-primary">{{ __('Recharge') }}</button>
              </div>
            </div>
        </form>
      </div>
    </div>
@endsection
