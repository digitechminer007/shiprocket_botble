{{-- resources/views/apitools.blade.php --}}
@extends('plugins.shiprocket::layouts.master')

@section('shiprocket-content')
    <h4>{{ __('Shiprocket API Tools') }}</h4>

    
@if(isset($couriers) && count($couriers))
    <h5 class="mt-4">{{ __('Available Courier Rates') }}</h5>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>{{ __('Courier Name') }}</th>
                <th>{{ __('Rate (INR)') }}</th>
                <th>{{ __('Estimated Delivery') }}</th>
                <th>{{ __('COD Available?') }}</th>
                <th>{{ __('Air/Surface') }}</th>
            </tr>
        </thead>
        <tbody>
            @foreach($couriers as $courier)
                <tr>
                    <td>{{ $courier['courier_name'] ?? '-' }}</td>
                    <td>₹{{ $courier['rate'] ?? '-' }}</td>
                    <td>{{ $courier['etd'] ?? '-' }}</td>
                    <td>
                        @if(($courier['cod'] ?? 0) == 1)
                            <span class="badge bg-success">Yes</span>
                        @else
                            <span class="badge bg-danger">No</span>
                        @endif
                    </td>
                    <td>{{ ucfirst($courier['mode'] ?? '-') }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endif
@if(isset($couriers) && empty($couriers))
    <div class="alert alert-warning mt-2">No courier rates found for the given details.</div>
@endif

