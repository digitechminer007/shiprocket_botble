@extends(Theme::getLayoutPath())

@section('content')
    <div class="container py-5">
        <h2 class="text-center mb-4">Track Your Order</h2>
        <iframe
            src="https://shiprocket.co/tracking/"
            width="100%"
            height="600"
            frameborder="0"
            scrolling="auto"
            title="Shiprocket Order Tracking"
        ></iframe>
    </div>
@endsection
