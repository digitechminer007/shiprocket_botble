﻿{{-- resources/views/settings.blade.php --}}
@extends('plugins.shiprocket::layouts.master')

@section('shiprocket-content')
    <form method="POST" action="{{ route('shiprocket.settings.update') }}">
        @csrf

        <h4>{{ __('Shiprocket API Credentials') }}</h4>
        <div class="mb-3">
            <label>{{ __('Email') }}</label>
            <input type="email" class="form-control" name="shipping_shiprocket_email" value="{{ setting('shipping_shiprocket_email') }}" required>
        </div>
        <div class="mb-3">
            <label>{{ __('Password') }}</label>
            <input type="password" class="form-control" name="shipping_shiprocket_password" value="{{ setting('shipping_shiprocket_password') }}" required>
        </div>

        <h4 class="mt-4">{{ __('Advanced Features') }}</h4>
        <div class="form-check form-switch">
            <input class="form-check-input" type="checkbox" id="sync_orders" name="shipping_shiprocket_sync_orders" value="1" {{ setting('shipping_shiprocket_sync_orders') ? 'checked' : '' }}>
            <label class="form-check-label" for="sync_orders">{{ __('Auto-sync Orders') }}</label>
        </div>
        <div class="form-check form-switch mt-2">
            <input class="form-check-input" type="checkbox" id="sync_status" name="shipping_shiprocket_sync_status" value="1" {{ setting('shipping_shiprocket_sync_status') ? 'checked' : '' }}>
            <label class="form-check-label" for="sync_status">{{ __('Auto-sync Status') }}</label>
        </div>
        <div class="form-check form-switch mt-2">
            <input class="form-check-input" type="checkbox" id="reverse_sync" name="shipping_shiprocket_reverse_sync" value="1" {{ setting('shipping_shiprocket_reverse_sync') ? 'checked' : '' }}>
            <label class="form-check-label" for="reverse_sync">{{ __('Enable Reverse Sync (Shiprocket → Site)') }}</label>
        </div>
        <button type="submit" class="btn btn-primary mt-4">{{ __('Save Settings') }}</button>
    </form>



        <br><br><br>



    <h4>{{ __('Shiprocket API Tools') }}</h4>
    <form method="POST" action="{{ route('shiprocket.apitools.testConnection') }}">
        @csrf
        <button class="btn btn-primary mb-3">{{ __('Test API Connection') }}</button>
    </form>
    <div id="api-test-result">
    @if(session('api_status'))
        @php $res = session('api_status'); @endphp
        <div class="alert alert-{{ $res['success'] ? 'success' : 'danger' }}">
            {{ $res['message'] }}
        </div>
        @if(isset($res['data']))
            <pre>{{ print_r($res['data'], true) }}</pre>
        @endif
    @endif
</div>

    <form method="POST" action="{{ route('shiprocket.apitools.rates') }}" class="mt-3">
        @csrf
        <div class="row g-2">
            <div class="col">
                <input type="text" name="from_pincode" class="form-control" placeholder="{{ __('From Pincode') }}" required>
            </div>
            <div class="col">
                <input type="text" name="to_pincode" class="form-control" placeholder="{{ __('To Pincode') }}" required>
            </div>
            <div class="col">
                <input type="number" name="weight" class="form-control" placeholder="{{ __('Weight (kg)') }}" step="0.1" required>
            </div>
            <div class="col">
                <button class="btn btn-primary mb-3">{{ __('Get Shipping Rates') }}</button>
            </div>
        </div>
    </form>
   @if(session('rate_result'))
    <div class="alert alert-success mt-2">
        <pre>{{ print_r(session('rate_result'), true) }}</pre>
    </div>
@endif
    
    @if(isset($couriers) && count($couriers))
    <h5 class="mt-4">{{ __('Available Courier Rates') }}</h5>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>{{ __('Courier Name') }}</th>
                <th>{{ __('Rate (INR)') }}</th>
                <th>{{ __('Estimated Delivery') }}</th>
                <th>{{ __('COD Available?') }}</th>
                <th>{{ __('Air/Surface') }}</th>
            </tr>
        </thead>
        <tbody>
            @foreach($couriers as $courier)
                <tr>
                    <td>{{ $courier['courier_name'] ?? '-' }}</td>
                    <td>₹{{ $courier['rate'] ?? '-' }}</td>
                    <td>{{ $courier['etd'] ?? '-' }}</td>
                    <td>
                        @if(($courier['cod'] ?? 0) == 1)
                            <span class="badge">Yes</span>
                        @else
                            <span class="badge">No</span>
                        @endif
                    </td>
                    <td>{{ ucfirst($courier['mode'] ?? '-') }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endif
@if(isset($couriers) && empty($couriers))
    <div class="alert alert-warning mt-2">No courier rates found for the given details.</div>
@endif
<br><br>

<div class="form-group mb-3">
    <label for="shiprocket_public_tracking_enabled" class="control-label">
        Enable Public Order Tracking Page?
    </label>
    <label class="me-3">
        <input type="radio" name="shiprocket_public_tracking_enabled" value="1"
            {{ setting('shiprocket_public_tracking_enabled', true) ? 'checked' : '' }}> Yes
    </label>
    <label>
        <input type="radio" name="shiprocket_public_tracking_enabled" value="0"
            {{ !setting('shiprocket_public_tracking_enabled', true) ? 'checked' : '' }}> No
    </label>
</div>

<div class="form-group mb-3 mt-3">
    <label for="shiprocket_tracking_page_url" class="control-label">
        Custom Tracking Page URL (optional)
    </label>
    <input type="text" name="shiprocket_tracking_page_url" id="shiprocket_tracking_page_url"
           class="form-control"
           placeholder="/track-order"
           value="{{ setting('shiprocket_tracking_page_url', '/track-order') }}">
    <small class="form-text text-muted">Default: <code>/track-order</code></small>
</div>



@endsection





{{-- At the bottom of your apitools.blade.php --}}
@push('scripts')
<script>
document.querySelector('form[action*="apitools/test"]').onsubmit = function(e) {
    e.preventDefault();
    fetch(this.action, {
        method: "POST",
        headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
    })
    .then(res => res.json())
    .then(data => {
        let box = document.getElementById('api-test-result');
        if (data.success) {
            box.innerHTML = `<div class="alert alert-success">${data.message}</div>`;
        } else {
            box.innerHTML = `<div class="alert alert-danger">${data.message}</div>`;
        }
    });
};
</script>
@endpush
