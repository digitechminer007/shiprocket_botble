{{-- resources/views/partials/sidebar.blade.php --}}
<div class="list-group mb-4">
    <a href="{{ route('shiprocket.dashboard') }}" class="list-group-item {{ Route::is('shiprocket.dashboard') ? 'active' : '' }}">
        <i class="fa fa-home"></i> {{ __('Dashboard') }}
    </a>
    <a href="{{ route('shiprocket.orders') }}" class="list-group-item {{ Route::is('shiprocket.orders') ? 'active' : '' }}">
        <i class="fa fa-truck"></i> {{ __('Orders') }}
    </a>
    <a href="{{ route('shiprocket.wallet') }}" class="list-group-item {{ Route::is('shiprocket.wallet') ? 'active' : '' }}">
        <i class="fa fa-wallet"></i> {{ __('Wallet') }}
    </a>
    <a href="{{ route('shiprocket.pickups.index') }}" class="list-group-item {{ Route::is('shiprocket.pickups') ? 'active' : '' }}">
        <i class="fa fa-map-marker"></i> {{ __('Pickups') }}
    </a>
    <a href="{{ route('shiprocket.settings') }}" class="list-group-item {{ Route::is('shiprocket.settings') ? 'active' : '' }}">
        <i class="fa fa-cogs"></i> {{ __('Settings') }}
    </a>
    <a href="{{ route('shiprocket.apitools') }}" class="list-group-item {{ Route::is('shiprocket.apitools') ? 'active' : '' }}">
        <i class="fa fa-wrench"></i> {{ __('API Tools') }}
    </a>
    <a href="{{ route('shiprocket.logs') }}" class="list-group-item {{ Route::is('shiprocket.logs') ? 'active' : '' }}">
        <i class="fa fa-clipboard-list"></i> {{ __('Logs') }}
    </a>
</div>
