{{-- pickups/create.blade.php --}}
@extends('plugins.shiprocket::layouts.master')

@section('shiprocket-content')
    <h4>{{ __('Add New Pickup Location') }}</h4>

    <form action="{{ route('shiprocket.pickups.store') }}" method="POST">
        @csrf
        <div class="mb-3">
            <label for="pickup_location">{{ __('Location Name') }}</label>
            <input type="text" name="pickup_location" id="pickup_location" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="address">{{ __('Address') }}</label>
            <textarea name="address" id="address" class="form-control" required></textarea>
        </div>
        <div class="mb-3">
            <label for="pin_code">{{ __('Pincode') }}</label>
            <input type="text" name="pin_code" id="pin_code" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="phone">{{ __('Phone') }}</label>
            <input type="text" name="phone" id="phone" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">{{ __('Save Pickup') }}</button>
    </form>
@endsection
