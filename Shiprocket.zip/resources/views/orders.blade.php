@extends('plugins.shiprocket::layouts.master')

@section('shiprocket-content')
    <h4 class="mb-3">{{ __('Shiprocket Orders') }}</h4>

    {{-- Show success/error flash messages --}}
    @if(session('status'))
        <div class="alert alert-success">{{ session('status') }}</div>
    @endif
    @if(session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

    <div class="mb-3">
        <a href="{{ route('shiprocket.orders.sync') }}" class="btn btn-primary">{{ __('Sync Orders Now') }}</a>
    </div>
    <table class="table table-bordered table-hover">
        <thead>
            <tr>
                <th>{{ __('Order Code') }}</th>
                <th>{{ __('Customer') }}</th>
                <th>{{ __('Shiprocket Status') }}</th>
                <th>{{ __('Order Status') }}</th>
                <th>{{ __('Actions') }}</th>
            </tr>
        </thead>
        <tbody>
        @forelse ($orders as $order)
            <tr>
                <td>{{ $order->code }}</td>

                <td>{{ $order->addresse->name ?? __('Guest') }}</td>
                <td>
                    @if ($order->shipment && $order->shipment->shiprocket_status)
                        <span class="badge bg-info">{{ $order->shipment->shiprocket_status }}</span>
                    @else
                        <span class="badge bg-secondary">{{ __('Not Synced') }}</span>
                    @endif
                </td>
                <td>
                    <span class="badge bg-{{ $order->status === 'delivered' ? 'success' : 'warning' }}">
                        {{ $order->status }}
                    </span>
                </td>
                <td>
                    @if (!$order->shipment || !$order->shipment->shiprocket_shipment_id)
                        <form action="{{ route('shiprocket.orders.syncSingle', $order->id) }}" method="POST" style="display:inline;">
                            @csrf
                            <button type="submit" class="btn btn-sm btn-success">
                                {{ __('Sync to Shiprocket') }}
                            </button>
                        </form>
                    @else
                        <a href="{{ route('shiprocket.orders.track', $order->id) }}" class="btn btn-sm btn-info">
                            {{ __('Track') }}
                        </a>
                    @endif
                </td>
            </tr>
        @empty
            <tr>
                <td colspan="5">{{ __('No orders found.') }}</td>
            </tr>
        @endforelse
        </tbody>
    </table>
@endsection
