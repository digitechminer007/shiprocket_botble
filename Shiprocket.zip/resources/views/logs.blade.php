{{-- resources/views/logs.blade.php --}}
@extends('plugins.shiprocket::layouts.master')

@section('shiprocket-content')
    <h4>{{ __('Shiprocket Logs') }}</h4>
    <pre style="background: #222; color: #0f0; max-height: 500px; overflow:auto;">
        {!! $logs !!}
    </pre>
@endsection
