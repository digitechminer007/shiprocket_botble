@extends('plugins.shiprocket::layouts.master')

@section('shiprocket-content')
    <h4>{{ __('Pickup Locations') }}</h4>
    <a href="{{ route('shiprocket.pickups.create') }}" class="btn btn-success mb-3">
        <i class="fa fa-plus"></i> {{ __('Add New Pickup') }}
    </a>

    @if(!empty($error))
        <div class="alert alert-danger">{{ $error }}</div>
    @endif

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>{{ __('Location Name') }}</th>
                <th>{{ __('Address') }}</th>
                <th>{{ __('Pincode') }}</th>
                <th>{{ __('Contact') }}</th>
                <th>{{ __('Actions') }}</th>
            </tr>
        </thead>
        <tbody>
        @forelse ($pickups as $pickup)
            <tr>
                <td>{{ $pickup['pickup_location'] ?? '—' }}</td>
                <td>{{ $pickup['address'] ?? '—' }}</td>
                <td>{{ $pickup['pin_code'] ?? '—' }}</td>
                <td>{{ $pickup['phone'] ?? '—' }}</td>
                <td>
                    <a href="{{ route('shiprocket.pickups.edit', $pickup['id']) }}" class="btn btn-warning btn-sm">{{ __('Edit') }}</a>
                    <form action="{{ route('shiprocket.pickups.destroy', $pickup['id']) }}" method="POST" style="display:inline;">
                        @csrf @method('DELETE')
                        <button class="btn btn-danger btn-sm" onclick="return confirm('{{ __('Delete?') }}')">{{ __('Delete') }}</button>
                    </form>
                </td>
            </tr>
        @empty
            <tr>
                <td colspan="5">{{ __('No pickup locations found.') }}</td>
            </tr>
        @endforelse
        </tbody>
    </table>
@endsection
