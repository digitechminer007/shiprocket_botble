{{-- resources/views/layouts/master.blade.php --}}
@extends('core/base::layouts.master')

@section('content')
    <div class="shiprocket-plugin">
        <div class="row">
            <!--<div class="col-md-2">-->
            <!--    @include('plugins.shiprocket::partials.sidebar')-->
            <!--</div>-->
            <div class="col-md-10">
                @yield('shiprocket-content')
            </div>
        </div>
    </div>
@endsection

@push('css')
    <!--<link rel="stylesheet" href="{{ asset('vendor/core/plugins/shiprocket/css/shiprocket.css') }}">-->
@endpush
