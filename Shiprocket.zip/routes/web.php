<?php

use Illuminate\Support\Facades\Route;
use Botble\Shiprocket\Http\Controllers\ShiprocketSettingController;
use Botble\Shiprocket\Http\Controllers\ShiprocketOrderController;
use Botble\Shiprocket\Http\Controllers\ShiprocketDashboardController;
use Botble\Shiprocket\Http\Controllers\ShiprocketWalletController;
use Botble\Shiprocket\Http\Controllers\ShiprocketPickupController;
use Botble\Shiprocket\Http\Controllers\ShiprocketApiToolsController;
use Botble\Shiprocket\Http\Controllers\ShiprocketPublicController;

Route::group([
    'prefix' => 'admin/shiprocket',
    'as'     => 'shiprocket.',
    'middleware' => ['web', 'auth'],
], function () {

    // Dashboard/overview
    Route::get('/', [ShiprocketDashboardController::class, 'index'])->name('dashboard');

    // Orders management
    Route::get('orders', [ShiprocketOrderController::class, 'index'])->name('orders');
    Route::post('orders/sync', [ShiprocketOrderController::class, 'sync'])->name('orders.sync');
    Route::get('orders/{order}/track', [ShiprocketOrderController::class, 'track'])->name('orders.track');
    Route::post('orders/{order}/sync', [ShiprocketOrderController::class, 'syncSingle'])->name('orders.syncSingle');

    // Wallet
    Route::get('wallet', [ShiprocketWalletController::class, 'index'])->name('wallet');
    Route::post('wallet/recharge', [ShiprocketWalletController::class, 'recharge'])->name('wallet.recharge');


    // Pickups CRUD
    Route::get('pickups', [ShiprocketPickupController::class, 'index'])->name('pickups.index');
    Route::get('pickups/create', [ShiprocketPickupController::class, 'create'])->name('pickups.create');
    Route::post('pickups', [ShiprocketPickupController::class, 'store'])->name('pickups.store');
    Route::get('pickups/{pickup}/edit', [ShiprocketPickupController::class, 'edit'])->name('pickups.edit');
    Route::put('pickups/{pickup}', [ShiprocketPickupController::class, 'update'])->name('pickups.update');
    Route::delete('pickups/{pickup}', [ShiprocketPickupController::class, 'destroy'])->name('pickups.destroy');


    // API Tools (test, get rates, etc.)
    Route::get('api-tools', [ShiprocketApiToolsController::class, 'index'])->name('apitools');
    Route::post('api-tools/test', [ShiprocketApiToolsController::class, 'testConnection'])->name('apitools.testConnection');
    Route::post('api-tools/rates', [ShiprocketApiToolsController::class, 'getRates'])->name('apitools.rates');

    // Settings
    Route::get('settings', [ShiprocketSettingController::class, 'index'])->name('settings');
    Route::post('settings', [ShiprocketSettingController::class, 'update'])->name('settings.update');
    
    //frontend
    Route::get('track-order', [ShiprocketPublicController::class, 'trackPage'])
    ->name('shiprocket.track');

    // Logs
    Route::get('logs', function() {
        $logs = @file_get_contents(storage_path('logs/shiprocket.log')) ?: 'No logs found.';
        return view('plugins/shiprocket::logs', compact('logs'));
    })->name('logs');
});
