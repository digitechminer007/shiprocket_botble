<?php

use Illuminate\Support\Facades\Route;
// You can define public API endpoints here if required.

Route::group([
    'prefix' => 'api/shiprocket',
    'as'     => 'api.shiprocket.',
    'middleware' => ['api'],
], function () {
    // Example: Webhook endpoint, or AJAX APIs for JS-based admin tools.
    // Route::post('webhook', [YourWebhookController::class, 'handle'])->name('webhook');
});
